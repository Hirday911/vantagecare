export default  {
Home :'BottomTab',
MYPROFILE:'MyProfile',
TIMESHEET:'TimeSheet',
MYSHIFT:'MyShift',
CERTIFICATES:'Certificates',
MESSAGES:'Messages'
}
