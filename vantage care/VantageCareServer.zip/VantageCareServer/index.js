const express = require("express");
const admin = require("firebase-admin");
const cors = require("cors");
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json()); // Parse JSON request bodies

// Firebase Admin Init
const serviceAccount = require("./vantage-care-firebase-adminsdk-fbsvc-048469b64d.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

// API Route to send push notification
app.post("/send-notification", async (req, res) => {
  const { token, title, body } = req.body;

  if (!token || !title || !body) {
    return res.status(400).json({ error: "token, title, and body are required" });
  }

  const message = {
    notification: {
      title,
      body,
    },
    token,
  };

  try {
    const response = await admin.messaging().send(message);
    console.log("Notification sent:", response);
    res.json({ success: true, response });
  } catch (error) {
    console.error("Error sending notification:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Start server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
